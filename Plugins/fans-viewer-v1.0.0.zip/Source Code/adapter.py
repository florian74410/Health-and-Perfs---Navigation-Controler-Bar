"""Descriptive plugin adapter. This script is not executed by NovaBar."""
PLUGIN_ID = "fans-viewer"
SENSOR_KEYS = ["fans"]
