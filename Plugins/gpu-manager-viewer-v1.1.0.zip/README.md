# GPU Manager/Viewer

GPU clock, load, temperature, VRAM and watts; alerts at 60%/85%

Import via Extensions > Plugin Manager. Built-in read-only telemetry.
