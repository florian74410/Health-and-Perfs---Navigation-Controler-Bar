"""Data-only built-in telemetry declaration (not executed)."""
PLUGIN_ID = 'gpu-manager-viewer'
SLOT = 'gpu'
SENSORS = ['gpu_clock_mhz', 'gpu_percent', 'gpu_temperature_c', 'gpu_power_w', 'vram_used_gb', 'vram_total_gb']
