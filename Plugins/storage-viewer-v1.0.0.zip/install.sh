#!/bin/sh
set -eu
test -f manifest.json && test -f DEPENDENCY.md && test -d Assets
echo 'Archive prête à être importée par le Plugin Manager NovaBar.'
