"""Descriptive plugin adapter. This script is not executed by NovaBar."""
PLUGIN_ID = "storage-viewer"
SENSOR_KEYS = ["disk_percent","disk_used_gb","disk_free_gb","disk_read_mbs","disk_write_mbs","disk_health_percent"]
