# Overclocking
Aucun contrôle matériel ni PWM fourni ici.
