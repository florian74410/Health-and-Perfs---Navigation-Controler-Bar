Réservé aux extensions web.
