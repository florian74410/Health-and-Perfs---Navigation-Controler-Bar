Réservé au thème HUD.
