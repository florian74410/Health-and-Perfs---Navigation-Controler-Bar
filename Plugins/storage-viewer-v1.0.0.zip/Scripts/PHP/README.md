Non requis par le runtime Qt.
