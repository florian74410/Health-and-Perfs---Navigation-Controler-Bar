# GPU Manager / Viewer v1.0.0

Module gpu du HUD Cyber-Futuriste Electric Blue.
Module de surveillance natif, données du service de fond, capteurs indisponibles signalés par un tiret.
