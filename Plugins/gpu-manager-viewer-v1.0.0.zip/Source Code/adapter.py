"""Descriptive plugin adapter. This script is not executed by NovaBar."""
PLUGIN_ID = "gpu-manager-viewer"
SENSOR_KEYS = ["gpu_clock_mhz","gpu_percent","gpu_temperature_c","gpu_power_w","vram_used_gb","vram_total_gb"]
