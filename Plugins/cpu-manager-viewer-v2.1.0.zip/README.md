# CPU Manager/Viewer

GHz: green 0-2, amber 2-3, red >3; 0-3.5 GHz dial

Import via Extensions > Plugin Manager. Built-in read-only telemetry.
