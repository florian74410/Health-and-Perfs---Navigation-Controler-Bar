# CPU CORE MATRIX

Native, no executable code in ZIP.
Click on the CPU slot after activating the CPU plugin.
Columns: Core/thread, frequency GHz, temperature °C, power W.
Final row: PACKAGE TOTAL (average clock, package temperature, measured package watts).
No synthetic TDP or core power values. Missing sensors shown as em dash.
