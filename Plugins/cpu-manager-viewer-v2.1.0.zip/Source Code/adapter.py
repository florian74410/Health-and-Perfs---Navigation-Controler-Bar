"""Data-only built-in telemetry declaration (not executed)."""
PLUGIN_ID = 'cpu-manager-viewer'
SLOT = 'cpu'
SENSORS = ['cpu_frequency_ghz', 'cpu_percent', 'cpu_temperature_c', 'cpu_cores', 'cpu_model', 'cpu_power_w', 'cpu_physical_cores', 'cpu_logical_cores']
