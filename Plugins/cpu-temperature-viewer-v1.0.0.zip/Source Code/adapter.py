"""Descriptive plugin adapter. This script is not executed by NovaBar."""
PLUGIN_ID = "cpu-temperature-viewer"
SENSOR_KEYS = ["cpu_temperature_c","cpu_percent"]
