# RAM Viewer

RAM percent, memory used and available

Import via Extensions > Plugin Manager. Built-in read-only telemetry.
