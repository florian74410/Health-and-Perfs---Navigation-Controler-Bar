"""Data-only built-in telemetry declaration (not executed)."""
PLUGIN_ID = 'ram-viewer'
SLOT = 'ram'
SENSORS = ['ram_percent', 'ram_used_gb', 'ram_available_gb']
