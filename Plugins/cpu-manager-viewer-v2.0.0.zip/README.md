# CPU Manager / Viewer v2.0.0

Module cpu du HUD Cyber-Futuriste Electric Blue.
**CPU Holographic Details v2** : cliquez dans le module CPU après activation du plugin ; le runtime NovaBar 0.3.2 affiche la CPU CORE MATRIX. L'installation du ZIP n'exécute aucun code externe.
