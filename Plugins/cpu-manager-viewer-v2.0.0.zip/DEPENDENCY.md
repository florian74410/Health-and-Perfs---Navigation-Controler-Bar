# Dépendances

- healthbar>=0.3.2
- Python>=3.10
- PySide6-Essentials>=6.8
- psutil>=5.9
- Accès lecture seulement aux capteurs du PC.
- Aucune installation automatique de bibliothèque ni exécution de install.sh.
