"""Descriptive plugin adapter. This script is not executed by NovaBar."""
PLUGIN_ID = "cpu-manager-viewer"
SENSOR_KEYS = ["cpu_frequency_ghz","cpu_percent","cpu_temperature_c","cpu_cores","cpu_model","cpu_physical_cores","cpu_logical_cores","cpu_power_w"]
