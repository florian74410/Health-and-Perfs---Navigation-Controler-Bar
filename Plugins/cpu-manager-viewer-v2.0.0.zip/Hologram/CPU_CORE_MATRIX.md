# CPU CORE MATRIX
Clic court sur CPU : ouverture neon. Lignes coeur physique si topologie vérifiée, sinon threads. Colonnes Core, GHz, °C, W. Dernière ligne package. Pas de TDP imaginé ; données absentes = —. Épinglage et fermeture ESC. Code rendu dans le runtime NovaBar >=0.3.2.
