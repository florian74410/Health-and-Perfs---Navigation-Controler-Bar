"""Data-only built-in telemetry declaration (not executed)."""
PLUGIN_ID = 'power-viewer'
SLOT = 'power'
SENSORS = ['power_total_w', 'power_mains_voltage_v', 'cpu_power_w', 'cpu_cores', 'cpu_package_voltage_v', 'gpu_power_w', 'gpu_core_voltage_v', 'gpu_core_power_w', 'gpu_vram_power_w', 'gpu_vram_voltage_v', 'ram_voltage_rails', 'battery_discharge_w']
