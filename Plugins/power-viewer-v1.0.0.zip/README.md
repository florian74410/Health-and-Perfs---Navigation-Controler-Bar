# Power Plugin

Power and voltage readings only when supported by the hardware sensor, never estimated

Import via Extensions > Plugin Manager. Built-in read-only telemetry.
