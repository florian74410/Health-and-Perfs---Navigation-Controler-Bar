# Fans Manager/Viewer

Discover available fan RPM sensors; no fan speed writes

Import via Extensions > Plugin Manager. Built-in read-only telemetry.
