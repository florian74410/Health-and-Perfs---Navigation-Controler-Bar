"""Data-only built-in telemetry declaration (not executed)."""
PLUGIN_ID = 'fans-viewer'
SLOT = 'fans'
SENSORS = ['fans']
