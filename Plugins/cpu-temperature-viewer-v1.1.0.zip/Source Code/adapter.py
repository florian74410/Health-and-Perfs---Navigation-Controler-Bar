"""Data-only built-in telemetry declaration (not executed)."""
PLUGIN_ID = 'cpu-temperature-viewer'
SLOT = 'cpu'
SENSORS = ['cpu_temperature_c', 'cpu_percent']
