# CPU Temperature Viewer

CPU temperature and load; red >=85%, critical >=95%

Import via Extensions > Plugin Manager. Built-in read-only telemetry.
