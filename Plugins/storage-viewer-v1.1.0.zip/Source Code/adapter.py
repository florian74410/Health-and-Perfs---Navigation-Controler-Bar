"""Data-only built-in telemetry declaration (not executed)."""
PLUGIN_ID = 'storage-viewer'
SLOT = 'storage'
SENSORS = ['disk_percent', 'disk_used_gb', 'disk_free_gb', 'disk_read_mbs', 'disk_write_mbs', 'disk_health_percent']
