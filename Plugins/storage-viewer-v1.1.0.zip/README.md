# HDD/SSD/NVMe Viewer

Storage gauge, used/free space, disk I/O rates; health when available

Import via Extensions > Plugin Manager. Built-in read-only telemetry.
