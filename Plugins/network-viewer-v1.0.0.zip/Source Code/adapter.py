"""Descriptive plugin adapter. This script is not executed by NovaBar."""
PLUGIN_ID = "network-viewer"
SENSOR_KEYS = ["net_down_mbs","net_up_mbs"]
