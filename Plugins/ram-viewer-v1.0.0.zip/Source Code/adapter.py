"""Descriptive plugin adapter. This script is not executed by NovaBar."""
PLUGIN_ID = "ram-viewer"
SENSOR_KEYS = ["ram_percent","ram_used_gb","ram_available_gb"]
