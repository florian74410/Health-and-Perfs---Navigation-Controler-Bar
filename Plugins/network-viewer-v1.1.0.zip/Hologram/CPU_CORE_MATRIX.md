# Sensor Holo

Native host panel. Click the top-right plugin logo; no hover activation.
