# Network Viewer

Network traffic up/down in MB/s

Import via Extensions > Plugin Manager. Built-in read-only telemetry.
