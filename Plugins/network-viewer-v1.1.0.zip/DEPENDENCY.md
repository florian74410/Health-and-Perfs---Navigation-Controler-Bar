# DEPENDENCY.md

- Python >= 3.10
- NovaBar >= 0.5.0
- PySide6-Essentials >= 6.8
- psutil >= 5.9
- Optional: nvidia-smi (NVIDIA GPU), lm-sensors/sysfs (Linux).
- No administrative access or automatic dependency installation.
