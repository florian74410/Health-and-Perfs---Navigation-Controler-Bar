"""Data-only built-in telemetry declaration (not executed)."""
PLUGIN_ID = 'network-viewer'
SLOT = 'network'
SENSORS = ['net_down_mbs', 'net_up_mbs']
