# Plugin profile

Per-user settings maintained by the host.
