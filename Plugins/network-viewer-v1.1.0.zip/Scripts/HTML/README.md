Reserved for optional web panels.
