Reserved for optional web themes.
