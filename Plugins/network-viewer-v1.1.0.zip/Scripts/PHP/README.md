Not required by native Qt runtime.
