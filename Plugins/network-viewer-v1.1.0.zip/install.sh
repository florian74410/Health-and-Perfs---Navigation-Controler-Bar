#!/bin/sh
set -eu
test -f manifest.json && test -f DEPENDENCY.md && test -d Assets
echo 'VALIDÉ: prêt à importer via NovaBar > Extensions'
